/*
 * Copyright (c) 2021, Renesas Electronics Corporation. All rights reserved.
 *
 * SPDX-License-Identifier: BSD-3-Clause
 */

#ifndef PFC_INIT_G2E_H
#define PFC_INIT_G2E_H

void pfc_init_g2e(void);

#endif /* PFC_INIT_G2E_H */
