/*
 * Copyright (c) 2018, Renesas Electronics Corporation. All rights reserved.
 *
 * SPDX-License-Identifier: BSD-3-Clause
 */

#ifndef RCAR_ULCB_CPLD_H__
#define RCAR_ULCB_CPLD_H__

extern void rcar_cpld_reset_cpu(void);

#endif /* RCAR_ULCB_CPLD_H__ */
